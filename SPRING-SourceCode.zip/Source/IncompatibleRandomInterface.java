public interface IncompatibleRandomInterface {
// Simply defines a method for retrieving the next random number
// This version won't work with the Game class defined
  public double getNextNumber();
}
